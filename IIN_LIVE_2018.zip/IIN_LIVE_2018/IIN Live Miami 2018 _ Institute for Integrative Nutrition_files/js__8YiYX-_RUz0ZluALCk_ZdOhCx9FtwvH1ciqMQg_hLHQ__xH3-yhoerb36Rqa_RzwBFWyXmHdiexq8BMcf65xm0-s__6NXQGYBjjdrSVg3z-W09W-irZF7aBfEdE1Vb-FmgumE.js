/* Source and licensing information for the line(s) below can be found at https://www.integrativenutrition.com/sites/default/files//js_injector/js_injector_96.js. */
jQuery(function($){$('.node-promo .click-processed').click(function(e){console.log('clicked on div');ga("create","UA-1231424-1",'auto');ga('send','event','Promo','Click','PromoDesktop');e.stopPropagation()})});;
/* Source and licensing information for the above line(s) can be found at https://www.integrativenutrition.com/sites/default/files//js_injector/js_injector_96.js. */
